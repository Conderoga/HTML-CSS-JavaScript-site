Brick-Breaker-Game
==================

Implementaiton of a simple game using HTML 5 and javascript as a learning activity.
